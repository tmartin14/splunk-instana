This is an add-on powered by the Splunk Add-on Builder.

Splunk Add-on for Instana
Copyright (C) 2005-2018 Splunk Inc. All Rights Reserved. 

